"""
Written by Liquid Glass
"""

textEncodingFormat = "utf-8"
