"""
Written by Liquid Glass
"""

unspentUtxoPath = "wallet/transaction/unspent/"
spentUtxoPath = "wallet/transaction/spent/"
unsafeUtxoPath = "wallet/transaction/unsafe/"
