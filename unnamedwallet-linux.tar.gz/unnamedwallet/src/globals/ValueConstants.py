"""
Written by Liquid Glass
"""

txFeeConst = int(1000)
keepAccountAliveAmountConst = int(100000)
